package com.example.coffeeorder;



import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import java.text.NumberFormat;
/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {
    int q = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the order button is clicked.
     */
    EditText e = (EditText)findViewById(R.id.edittext_Name);
    String name = e.getText().toString();
    public void increment(View view){

        q = q+1;

        display(q);
    }
    public void decrement(View view){

        q = q-1;
        display(q);
    }
    public void submitOrder(View view) {



        String p =  "Thanks for your order" + " \nyou have ordered " + q + " cups of cofee" +  "" +
                "\nHave a good day  "+ name;
        displayPrice(addon(q));
        displayMessage(p);


    }
    public void composeEmail (View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("*/*");
        String pr =  "Thanks for your order" + " \nyou have ordered " + q + " cups of cofee" +  "" +
                "\nHave a good day  "+ name;
        intent.putExtra(Intent.EXTRA_SUBJECT, "JUST JAVA coffee order");
        intent.putExtra(Intent.EXTRA_TEXT,pr);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }




    private int addon(int number){
        CheckBox q = (CheckBox) findViewById(R.id.With_Biscuit);
        CheckBox p = (CheckBox) findViewById(R.id.With_Chocolate);
        if(q.isChecked() && p.isChecked()){
            return number+ 3;
        }
        if(!q.isChecked() && p.isChecked()){
            return number+ 1;
        }
        if(q.isChecked() && !p.isChecked()){
            return number+ 2;
        }
        else{
            return number;
        }



    }


    /**
     * This method displays the given quantity value on the screen.
     * @return
     */


    private void displayPrice(int number) {
        TextView priceTextView = (TextView) findViewById(R.id.price_text_view);
        int num = number* 5;
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(num));


    }
    private void displayMessage(String message) {
        TextView priceTextView = (TextView) findViewById(R.id.price_text_view2);
        priceTextView.setText(message);
    }

    private void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }//STRING TYPE HAI
}
